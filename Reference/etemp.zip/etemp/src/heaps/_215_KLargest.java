package heaps;

import java.util.PriorityQueue;

public class _215_KLargest {

    /**
     * Approach 1: Priority Queue
     * <p>
     * TC: O(n log k)
     * SC: O(n) Worst case
     */
    public int findKthLargest(int[] nums, int k) {
        PriorityQueue<Integer> pq = new PriorityQueue<>();

        for (int i : nums) {
            pq.offer(i);

            if (pq.size() > k)
                pq.poll();
        }

        return pq.poll();
    }

    /**
     * Quick Select Template
     * ---------------------
     * The below code is the Quick Select Template to find the kth something in an array.
     * <p>
     * Approach 2: Quick Select
     * <p>
     * TC: O(n) - Average case, O(n ^ 2) - Worst case
     * SC: O(1)
     */
    public int findKthLargest2(int[] nums, int k) {
        return quickSelect(nums, 0, nums.length - 1, nums.length - k);
    }

    private int quickSelect(int[] nums, int left, int right, int nk) {
        while (left < right) {
            int partitionPos = partition(nums, left, right);

            if (partitionPos == nk)
                return nums[partitionPos];
            else if (partitionPos < nk)
                left = partitionPos + 1;
            else
                right = partitionPos - 1;
        }
        return nums[left];
    }

    private int partition(int[] nums, int left, int right) {
        int pivotIdx = left + (right - left) / 2, j = left;
        swap(nums, pivotIdx, right);
        pivotIdx = right;

        for (int i = left; i <= right; i++) {
            if (nums[i] < nums[pivotIdx]) {
                swap(nums, i, j);
                j++;
            }
        }

        swap(nums, right, j);
        return j;
    }

    private void swap(int[] nums, int first, int second) {
        if (first == second)
            return;

        int temp = nums[first];
        nums[first] = nums[second];
        nums[second] = temp;
    }

    public static void main(String[] args) {
        _215_KLargest kl = new _215_KLargest();
        System.out.println(kl.findKthLargest(new int[]{1}, 1));
        System.out.println(kl.findKthLargest2(new int[]{6, 71, 25, 38, 17, 23, 0, 19, 3, 46, 27, 3, 48, 1, 2}, 6));
    }
}
