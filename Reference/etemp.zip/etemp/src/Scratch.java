import java.text.SimpleDateFormat;
import java.util.*;

public class Scratch {
    public static void main(String[] args) {
        Scratch s = new Scratch();
        String pattern = "yyyy-MM-dd HH:mm:ss Z";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
        String date = simpleDateFormat.format(new Date());
        System.out.println(date);
    }
}