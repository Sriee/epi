package trie;

public class TrieNode {
    public boolean isWord = false;
    public TrieNode[] child;

    public TrieNode() {
        this.child = new TrieNode[26];
    }
}
