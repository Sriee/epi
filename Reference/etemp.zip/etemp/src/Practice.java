import tree.TreeNode;
import tree.TreeUtils;

import java.util.*;

public class Practice {

    public TreeNode balance(TreeNode root) {
        TreeNode grand = new TreeNode(-1);
        grand.right = root;

        int n = makeWine(grand);
        int h = (int)(Math.log(n + 1)/Math.log(2));
        int m = (int)(Math.pow(2, h) - 1);

        construct(grand, n - m);
        for (m = m / 2; m > 0; m /= 2) {
            construct(grand, m);
        }

        return grand.right;
    }

    private int makeWine(TreeNode grand) {
        TreeNode curr = grand.right, temp;
        int count = 0;

        while (curr != null) {
            if (curr.left != null) {
                temp = curr;
                curr = curr.left;
                temp.left = curr.right;
                curr.right = temp;
                grand.right = curr;
            } else {
                count++;
                grand = curr;
                curr = curr.right;
            }
        }
        return count;
    }

    private void construct(TreeNode grand, int m) {
        TreeNode curr = grand.right, temp;

        while (m-- > 0) {
            temp = curr;
            curr = curr.right;
            grand.right = curr;
            temp.right = curr.left;
            curr.left = temp;
            grand = curr;
            curr = curr.right;
        }
    }

    public void cyclicSort(int[] nums) {
        int i = 0, n = nums.length;
        while (i < n) {
            int correct = nums[i] - 1;

            if (correct < n && nums[i] != nums[correct]) {
                swap(nums, i, correct);
            } else {
                i++;
                System.out.println(i);
            }
            System.out.println(Arrays.toString(nums));
        }
    }

    public TreeNode inorderSuccessor(TreeNode root, TreeNode p) {
        TreeNode iter = root, successor = null;

        while (iter != null) {
            if (iter.val > p.val) {
                successor = iter;
                iter = iter.left;
            } else {
                iter = iter.right;
            }
        }

        return successor;
    }

    public List<Integer> morrisTraversal(TreeNode root) {
        List<Integer> res = new ArrayList<>();
        TreeNode curr = root, pred = null;

        while (curr != null) {
            if (curr.left != null) {
                pred = curr.left;
                while (pred.right != null && pred.right != curr)
                    pred = pred.right;

                if (pred.right != null) {
                    pred.right = curr;
                    curr = curr.left;
                } else {
                    res.add(curr.val);
                    pred.right = null;
                    curr = curr.right;
                }
            } else {
                res.add(curr.val);
                curr = curr.right;
            }
        }
        return res;
    }

    private void swap(int[] nums, int first, int second) {
        int temp = nums[first];
        nums[first] = nums[second];
        nums[second] = temp;
    }

    public static void main(String[] args) {
        Practice p = new Practice();
        int[] nums = {4, 3, 2, 7, 8, 2, 3, 1};
        p.cyclicSort(nums);
    }

}
