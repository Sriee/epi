package tree;

public class TreeNode {
    public int val;
    public TreeNode left, right;

    public TreeNode(int x) {
        this.val = x;
    }

    public TreeNode(int x, TreeNode left, TreeNode right) {
        this.val = x;
        this.left = left;
        this.right = right;
    }

    @Override
    public String toString() {
        return "TreeNode(" + this.val + ")";
    }
}
